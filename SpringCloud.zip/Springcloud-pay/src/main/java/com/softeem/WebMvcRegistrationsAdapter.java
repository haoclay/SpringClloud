package com.softeem;

import org.springframework.boot.autoconfigure.web.servlet.WebMvcRegistrations;

public class WebMvcRegistrationsAdapter implements WebMvcRegistrations {
}
